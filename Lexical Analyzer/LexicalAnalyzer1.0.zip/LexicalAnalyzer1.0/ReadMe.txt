Please open the LexicalAnalyzer.exe file to use the app.
The presence of other files in this folder is required for the LexicalAnalyzer.exe to work properly.

To check the source code, unzip "LexicalAnalyzer1.0 SourceCode.zip", & open the .sln file using Visual Studio.


Thanks,
ariannavabi@gmail.com